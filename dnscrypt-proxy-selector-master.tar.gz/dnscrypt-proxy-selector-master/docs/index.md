<head>
<title>DNSCRYPT-PROXY-SELECTOR</title>
<link rel="stylesheet" type="text/css" href="main.css"/>
</head>

<div id="header">
<center><br><h1>DNSCRYPT-PROXY-SELECTOR</h1></center></div>
<br>
<br>

<center><p>DNSCRYPT-PROXY-SELECTOR Is Designed To Allow Linux Users To Select Which Dns Proxy To Use. <br> This Would Mean From a 
Selection of 50+ Servers you can Get Dns From Uncensored Countries Such As Iceland Or Romainia.<br> It's Recomended To Use DNSCRYPT
with VPN (Virtual Private Network) But You Can Use It With Tor (The Onion Router) As Well.</p></center>

<a href="https://github.com/josh788/dnscrypt-proxy-selector/archive/master.zip"><button>DOWNLOAD AS .ZIP</button></a>

<p>Or To DOWLOAD Using git Use <b>git clone https://github.com/josh788/dnscrypt-proxy-selector.git</b></p>

<br>
<br>

<div id="footer"><center>&copy;2017 BY Joshua Chambers / Josh788</center></div>

